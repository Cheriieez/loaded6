<?php
/*
  $Id: affiliate_logout.php,v 1.2 2004/03/05 00:36:42 ccwjr Exp $

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/
define('NAVBAR_TITLE_LOGOUT', 'Log out');
define('NAVBAR_TITLE', 'The Affiliate Program');
define('HEADING_TITLE', 'The Affiliate Program');

define('TEXT_INFORMATION', 'You were logged out successfully.');
define('TEXT_INFORMATION_ERROR_1', 'You could not be logged out.');
define('TEXT_INFORMATION_ERROR_2', 'You were not logged in and can therefore not be logged out.');
?>