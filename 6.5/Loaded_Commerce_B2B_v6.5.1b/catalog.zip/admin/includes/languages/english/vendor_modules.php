<?php
/*
  $Id: modules.php,v 1.6 2003/05/28 14:07:36 hpdl Exp $

  Modified for MVS V1.0 2006/03/25 JCK/CWG
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2006 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE_MODULES_SHIPPING', 'Vendor Shipping Modules');
define('TABLE_HEADING_MODULES', 'Vendor Modules');
define('TABLE_HEADING_SORT_ORDER', 'Sort Order');
define('TABLE_HEADING_ACTION', 'Action');
define('TEXT_MODULE_DIRECTORY', 'Vendor Module Directory:');
define('TEXT_NO_VENDOR_SELECTED', 'No Vendor Selected! Please go back and select a Vendor. Check your installation.<br><br>');
define('CURRENTLY_MANAGING', 'You are currently managing  <b>');
define('CURRENTLY_MANAGING_2', '</b><br> If you want to select another Vendor, go ');
define('CURRENTLY_MANAGING_3', 'back to the Manager Page.');
?>