<?php
/*
  $Id: stats_articles_viewed.php,v 1.5 2005/03/01 15:51:03 info@bridegroompress.com Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Top Viewed Articles');

define('TABLE_HEADING_NUMBER', 'No.');
define('TABLE_HEADING_ARTICLES', 'Articles');
define('TABLE_HEADING_VIEWED', 'Viewed');
?>
