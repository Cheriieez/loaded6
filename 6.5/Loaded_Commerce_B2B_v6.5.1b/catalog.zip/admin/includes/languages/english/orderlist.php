<?php
/*
  $Id: orderlist.php,v 1.25 2003/06/20 00:28:44 vj Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/
define('HEADING_TITLE', 'Orderlist');
define('HEADING_TITLE_STATUS', 'Status:');
define('TABLE_HEADING_ORDER_ID', 'Order ID');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Model');
define('TABLE_HEADING_PRODUCTS_NAME', 'Product Name');
define('TABLE_HEADING_PRICE', 'Price');
define('TABLE_HEADING_QUANTITY', 'Qty');
define('TABLE_HEADING_NOTES', 'Notes');
define('TABLE_HEADING_CHK', 'Chk');
define('TEXT_ALL_ORDERS', 'All Orders');
define('TEXT_DOWNLOAD', 'Download');
define('TEXT_PRINT', 'Print');
?>