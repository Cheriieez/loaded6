<?php
/*
  $Id: fss_view_customers.php,v 1.0.0.0 2006/10/21 23:39:49 datazen Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2006 CRE Loaded
  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'View Customers');
define('TEXT_HEADING_CUSTOMERS_FIRSTNAME', 'Firstname');
define('TEXT_HEADING_CUSTOMERS_LASTNAME', 'Lastname');
define('TEXT_HEADING_CUSTOMERS_STATE', 'State');
define('TEXT_HEADING_CUSTOMERS_COUNTRY', 'Country');
define('TEXT_HEADING_CUSTOMERS_EMAIL', 'Email');
define('TEXT_HEADING_CUSTOMERS_PHONE', 'Phone');
define('TEXT_HEADING_ACTION', 'Action');
define('TEXT_INFORBOX_CUSTOMERS_HEADING', 'Customer %s');
?>