<?php
/*
  $Id: affiliate_contact.php,v 1.2 2004/03/05 00:36:42 ccwjr Exp $

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Affiliate Program');
define('HEADING_TITLE', 'Affiliate Program - Contact Form');

define('TEXT_SUCCESS', 'Your message has been successfully sent to the Affiliate Program Team');

define('EMAIL_SUBJECT', 'Affiliate Program');
define('ENTRY_NAME', 'Your Full Name:');
define('ENTRY_EMAIL', 'Your Email Address:');
define('ENTRY_ENQUIRY', 'Your Message:');

define('TEXT_AFFILIATE','Affiliate ');
define('TEXT_FROM','From');
define('TEXT_SUBJECT','Subject');
define('TEXT_MESSAGE','Message');
define('TEXT_SELECT_AFFILIATE','Select Affiliate'); 
define('TEXT_ALL_AFFILIATES','All Affiliates');

?>