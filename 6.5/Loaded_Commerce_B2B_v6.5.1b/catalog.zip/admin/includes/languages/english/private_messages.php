<?php
/*
  $Id: customers.php,v 1.12 2002/01/12 18:46:27 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Private Messages');
define('HEADING_TITLE_CREATE', 'Send Private Message to: ');
define('HEADING_TITLE_SEARCH', 'Search:');
define('TABLE_HEADING_PRIVATE_MESSAGE_ID', 'Id');
define('TABLE_HEADING_PRIVATE_MESSAGE_DESC', 'Message');
define('TABLE_HEADING_PRIVATE_MESSAGE_DATE', 'Message Date');
define('TABLE_HEADING_PRIVATE_MESSAGE_STATUS', 'Have Seen');
define('TABLE_HEADING_PRIVATE_MESSAGE_ACTIONS', 'Actions');
define('TABLE_HEADING_ACTION', 'Actions');
define('TABLE_HEADING_NAME', 'Customer Name');
define('HEADING_CUSTOMERS_PRIVATE_MESSAGES', 'Message:');
define('CATEGORY_MESSAGES', 'Messages');  
define('IMAGE_BUTTON_INSERT_ALL', 'Send Private Message To All Customers');  
define('IMAGE_BUTTON_INSERT', 'Send Private Message');  
define('IMAGE_BUTTON_DELETE', 'Delete Private Message');  

?>
