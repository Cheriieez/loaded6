<?php
/*
  $Id: products_expected.php,v 1.2 2004/03/05 00:36:41 ccwjr Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Edit Configuration Group');

define('TABLE_HEADING_PRODUCTS', 'Configuration Title');
define('TABLE_HEADING_DATE_EXPECTED', '');
define('TABLE_HEADING_ACTION', 'Action');
define('TEXT_CONFIG_TITLE', 'Configuration Title');
define('TEXT_CONFIG_VALUE','Configuration Value');
define('TEXT_CONFIG_DESCRIPTION','Configuration Description');
define('TEXT_CONFIG_GROUP','Configuration Group');
?>
