<?php
/*
  Id: account.php,v 1.1.1.1 2009/11/04 15:16:30 WGS/Paul Fahey/Mahesh Sawant Exp

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License

  Copyright &copy; 2003-2009 Chain Reaction Works, Inc.

  Last Modified by : $AUTHOR$
  Latest Revision  : $REVISION$
  Last Revision Date : $DATE$
  License :  GNU General Public License 2.0

  http://creloaded.com
  http://creforge.com

*/
define('TITLE_HEADING','Customer Email Address Export');
define('TEXT_DESC', '<br><b>What it does? </b><br><br>This web application will export selected users from your database, who either signed up for your newsletter or not  or all users to a CSV file.<br>This can be handy if you need a CSV of selected users for uploading to another application or to import existing users into a third party email program.<br><br>');
define('FRM_TXT','Select From date :');
define('GEN_TXT','News Letter : ');
define('TO_TXT','Select To Date : ');
define('NEWS_TXT','News Letter :');
define('ACT_TXT','Has Account created :');
define('CGRP_TXT','Choose Customers Group :');
define('TXT_HEADING','First name, Last name, Email Address, Date of Birth, Created with account, Newsletter, Account Created date, Gender, Last Purchase date, No of Orders, Order total');
define('TXT_B2B_HEADING','First name, Last name, Email Address, Date of Birth, Customers Group, Created with account, Newsletter, Account Created date, Gender, Last Purchase date, No of Orders, Order total');
?>