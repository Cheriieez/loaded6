<?php
/*
  $Id: cds_popup_preview.php,v 1.0.0.0 2007/02/27 13:41:11 datazen Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2007 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_CDS_CLICK_TO_PAGE_SOURCE','View Page source');
define('TEXT_CDS_CLOSE_WINDOW', 'Close this Window');
define('TEXT_CDS_VIEW_OUTPUT', 'View Page Output');

?>