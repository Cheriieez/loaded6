<?php
/*

  Copyright (c) 2005 Chainreactionworks.com

  Released under the GNU General Public License
  Original Author: $Author$
  Revision $Revision$
  
*/


define('HEADING_TITLE_01', 'Edit Languages: Introduction ');
define('HEADING_TITLE_02', 'Edit Languages: Search ');
define('HEADING_TITLE_03', 'Edit Languages: Edit ');
define('HEADING_TITLE_04', 'Edit Languages: Save');
define('HEADING_TITLE_05', 'Edit Languages: Restore');
define('MENU_ITEM_01', 'Introduction:');
define('MENU_ITEM_02', '1. Search for files or text');
define('MENU_ITEM_03', '2. Edit text define');
define('MENU_ITEM_04', '3. Saving your work ');
define('MENU_ITEM_05', '4. Restore to last copy of define file');

define('TEXT_MSG_1', 'Language Editor Help Index');
?>
