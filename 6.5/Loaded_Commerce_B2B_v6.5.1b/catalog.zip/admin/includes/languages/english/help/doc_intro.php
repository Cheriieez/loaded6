<?php
/*

  Copyright (c) 2005 Chainreactionworks.com

  Released under the GNU General Public License
  Original Author: $Author$
  Revision: $Revision$
  
*/


define('HEADING_TITLE1', 'Data Export/Import system');
define('HEADING_TITLE2', 'EP Advance Import');
define('HEADING_TITLE3', 'EP Advance Export');
define('HEADING_TITLE4', 'EP Basic Import');
define('HEADING_TITLE5', 'EP Basic Export');
define('HEADING_TITLE6', 'Editing the export file');
define('HEADING_TITLE9', 'Introduction to data feed');
define('HEADING_TITLE10', '7 Steps to your First Froogle Feed');
define('HEADING_TITLE11', 'Configure A Feed');
define('HEADING_TITLE12', 'Run A Feed');
?>
