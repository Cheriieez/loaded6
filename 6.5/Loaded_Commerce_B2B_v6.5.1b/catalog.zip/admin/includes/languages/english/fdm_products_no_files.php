<?php
/*
  $Id: fdm_products_no_files.php,v 1.0.0.0 2007/01/04 13:41:11 datazen Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2006 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Products With No Files Attached');
define('TABLE_HEADING_NUMBER', 'No.');
define('TABLE_HEADING_PRODUCT_ID', 'Product ID');
define('TABLE_HEADING_PRODUCT_NAME', 'Product Name');
define('TEXT_DISPLAY_NUMBER_OF_PRODUCT', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> Products)');

?>