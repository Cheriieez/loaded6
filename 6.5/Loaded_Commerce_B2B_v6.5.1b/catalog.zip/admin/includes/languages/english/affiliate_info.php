<?php
/*
  $Id: affiliate_info.php,v 1.2 2004/03/05 00:36:42 ccwjr Exp $

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Affiliate Program');
define('HEADING_TITLE', 'Affiliate Program');

define('HEADING_AFFILIATE_PROGRAM_TITLE', 'The ' . STORE_NAME . ' Affiliate Program');

// Delete this line - or place two forward slashes before the word 'define'
define('TEXT_INFORMATION', 'Your Affiliate Information Goes in /catalog/includes/languages/YOUR LANGUAGE/affiliate_info.php ');

// define('TEXT_INFORMATION',' <DELETE THE BRACKETS AND ALL TEXT IN BETWEEN - PUT YOUR INFORMATION HERE>');
?>
