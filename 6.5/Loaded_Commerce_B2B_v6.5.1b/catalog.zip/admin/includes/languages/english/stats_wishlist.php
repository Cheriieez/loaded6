<?php
define('TEXT_OF_CUSTOMER','Customer');
define('TEXT_OF_PRODUCTS_LIST','Products in List');
define('TEXT_OF_WISHLIST','Wishlist Report');
define('TEXT_OF_PRODUCT','Product');
define('TEXT_OF_MODEL','Model');
define('TEXT_OF_PRICE','Price');
?>