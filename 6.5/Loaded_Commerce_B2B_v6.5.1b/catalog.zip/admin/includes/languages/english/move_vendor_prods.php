<?php
/*
  $Id: move_vendor_prods.php,v 1.1 2008/06/22 22:50:52 datazen Exp $

  Modified for MVS V1.0 2006/03/25 JCK/CWG
  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2008 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/
define('HEADING_TITLE', 'Vendor Products Switcher');
define('TEXT_VENDOR_CHOOSE_MOVE', 'Choose the Vendor who\'s products you want to move.');
define('TEXT_VENDOR_CHOOSE_MOVE_TO', 'Choose the Vendor where you want the  products moved to.');

?>