<?php
/*
  $Id: affiliate_banners_category.php,v 2.00 2003/10/12

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Affiliate Program');
define('HEADING_TITLE', 'Affiliate Program - Category Links');

define('TEXT_AFFILIATE_NAME', 'Pre Defined Category Name:');
define('TEXT_INFORMATION', 'Choose from the provided banner links for categories you want to display on your website from the choices below:');
define('TEXT_AFFILIATE_INFO', 'Copy the code shown below and paste into your website');
define('TEXT_IMAGE', 'Clickable Image Version:');
define('TEXT_VERSION', 'Text Version:');

?>