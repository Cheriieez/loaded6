<?php
/*
  $Id: create_account_success.php,v 1.2 2004/03/05 00:36:41 ccwjr Exp $

  The Exchange Project - Community Made Shopping!
  http://www.theexchangeproject.org

  Copyright (c) 2000,2001 The Exchange Project

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Create an Account');
define('NAVBAR_TITLE_2', 'Success');
define('HEADING_TITLE', '<font color="#00CC33">Success:&nbsp;&nbsp;</font>Customer\'s Account Has Been Created!');
define('BUTTON_TITLE1', 'You can now take a manual order:');
define('BUTTON_TITLE2', 'Create another new customer account:');
define('BUTTON_TITLE3', 'Exit to Admin home page:');

define('IMAGE_BUTTON_CREATE_ORDER', 'create order');
define('IMAGE_BUTTON_CREATE_CUSTOMER', 'new customer');
define('IMAGE_BUTTON_ADMIN_HOME', 'admin home');

define('TEXT_ACCOUNT_CREATED', '');
?>
