<?php
/*
  $Id: fss_view_customers.php,v 1.0.0.0 2006/10/21 23:39:49 datazen Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2006 CRE Loaded
  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'View Orders');
define('TEXT_HEADING_CUSTOMERS_NAME', 'Customers');
define('TEXT_HEADING_ORDER_TOTAL', 'Order Total');
define('TEXT_HEADING_DATE_PURCHASED', 'Date Purchased');
define('TEXT_HEADING_STATUS', 'Status');
define('TEXT_HEADING_ACTION', 'Action');
define('TEXT_INFORBOX_ORDERS_HEADING', 'Order #%s');
?>