<?php
/*
  $Id: fdm_customer_download_log.php,v 1.0.0 2006/10/14 00:36:41 eversun Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2006 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Customer Download Logs');
define('HEADING_TITLE_FILE', 'File');

define('TABLE_HEADING_NAME', 'Extention Name');
define('TABLE_HEADING_STATUS', 'Status');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_DOWNLOAD_LOG', 'Download Logs');
define('HEADING_TITLE_LOG', 'Customer Downloads');
define('TABLE_HEADING_TIME_STAMP', 'Downloaded Date');
define('TABLE_HEADING_SIZE', 'Size');
define('TABLE_HEADING_FILE_DATE', 'File Creation Date');
define('TABLE_HEADING_PAGE', 'Downloaded From');
define('TABLE_HEADING_IP', 'IP');
define('TEXT_DISPLAY_NUMBER_FILES', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> Files)');
define('TEXT_CUSTOMER', 'Customer: ');
define('TEXT_FILE_UNAVAILABLE', 'File Unavailable');

?>