<?php
/*
  $Id: cds_popup.php,v 1.0.0.0 2007/02/27 13:41:11 datazen Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2007 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_CDS_CLICK_TO_PAGE_SOURCE','View Page Source');
define('TEXT_CDS_CLOSE_WINDOW', 'Close Window');
define('TEXT_VIEW_WINDOW', 'View Page Output');
define('FILE_EMPTY','File is Empty');
define('FILE_NOT_AVAILABE','File Is Not Available');

?>