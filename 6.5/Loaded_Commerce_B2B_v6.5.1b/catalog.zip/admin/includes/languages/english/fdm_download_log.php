<?php
/*
  $Id: fdm_download_log.php,v 1.0.0.0 2007/01/04 13:41:11 avicrw Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2006 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Download Log');
define('TABLE_HEADING_NUMBER', 'ID');
define('TABLE_HEADING_FILE_DESCRIPTIVE_NAME', 'File Descriptive Name');
define('TABLE_HEADING_FILE_NAME', 'Filename');
define('TABLE_HEADING_IP', 'IP');
define('TABLE_HEADING_CUSTOMER_ID', 'Customer');
define('TABLE_HEADING_PAGE', 'Downloaded From');
define('TABLE_HEADING_DATE_TIME', 'Date/Time');
define('TEXT_DISPLAY_FILE_SIZE', 'File Size');
define('TEXT_DISPLAY_GUEST', 'Guest');
define('TEXT_DISPLAY_NUMBER_OF_FILES', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> Files)');

?>