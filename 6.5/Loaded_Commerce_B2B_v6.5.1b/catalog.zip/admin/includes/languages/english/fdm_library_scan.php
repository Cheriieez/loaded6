<?php
/*
  $Id: fdm_library_scan.php,v 1.0.0.0 2006/10/09 23:39:49 datazen Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2006 CRE Loaded
  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Library File Scan');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_FILES', 'Files:');

define('TABLE_NEW_HEADING_NAME', 'New Files Found');
define('TABLE_NEW_HEADING_DATE', 'Date Uploaded');
define('TABLE_NF_HEADING_NAME', 'Files No Longer Found on Disk');
define('TABLE_NF_HEADING_DATE', 'Added Date');
define('TABLE_CHG_HEADING_NAME', 'Files that have Changed');
define('TABLE_CHG_HEADING_DATE', 'Added Date');

define('TEXT_INFO_HEADING_DELETE_CONFIRM', 'Delete file:');
define('TEXT_INFO_DELETE_INTRO', 'You really want to delete this file?');
define('TEXT_INFO_DELETE_QUERY', 'Are you sure you want to delete this file?');

?>