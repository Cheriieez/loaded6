<?php
/*
  $Id: stats_products_notifications.php,v 2.0 2008/05/05 00:36:41 datazen Exp $

  CRE Loaded, Commerical Open Source eCommerce
  http://www.creloaded.com

  Copyright (c) 2008 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Product Notifications');
define('TABLE_HEADING_NUMBER', 'No.');
define('TABLE_HEADING_PRODUCTS', 'Products');
define('TABLE_HEADING_COUNT', 'Notifications Count');
define('TABLE_HEADING_NAME', 'Customers Name');
define('TABLE_HEADING_EMAIL', 'Customers Email Address');
define('TABLE_HEADING_DATE', 'Notification Set on');
define('TEXT_DESCRIPTION', 'Allows you to see the number of customer notifications per product. Click on product name to see details. ');
define('TEXT_DESCRIPTION_TO', 'Allows you to see the customers that wanted to be notified for ');

?>