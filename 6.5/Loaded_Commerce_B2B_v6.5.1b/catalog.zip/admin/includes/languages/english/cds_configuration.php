<?php
/*
  $Id: cds_configuration.php,v 1.1.1.1 2007/01/11 datazen Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2007 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'CDS Configuration');
define('TABLE_HEADING_PAGE_TITLE','Title');
define('TABLE_HEADING_PAGE_VALUE','Value');
define('TABLE_PAGE_ACTION','Action');
define('TEXT_INFO_DATE_ADDED', 'Date Added:');
define('TEXT_INFO_LAST_MODIFIED','Last Modified:');

?>