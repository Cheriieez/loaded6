<?php
/*
  $Id: stats_customers.php,v 2.0 2008/05/05 00:36:41 datazen Exp $

  CRE Loaded, Commerical Open Source eCommerce
  http://www.creloaded.com

  Copyright (c) 2008 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Customer Order Totals');
define('TABLE_HEADING_NUMBER', 'No.');
define('TABLE_HEADING_CUSTOMERS', 'Customers');
define('TABLE_HEADING_TOTAL_PURCHASED', 'Total Purchased');

?>