<?php
/*
  $Id:$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2004 osCommerce

  Released under the GNU General Public License

*/

 define('TABLE_HEADING_DELETE', 'Delete');
 define('TABLE_HEADING_ID', 'Customer ID');
 define('TABLE_HEADING_CUSTOMERS', 'Username');
 define('TABLE_HEADING_EMAIL', 'Email');
 define('TABLE_HEADING_LAST_LOGON', 'Last login');
 define('HEADING_TITLE', 'Customers Not Validated');
 define('TABLE_HEADING_ACCOUNT_CREATED', 'Account Created');
 define('SIU_BACK', 'Back');
 define('SIU_DELETE', 'Delete!');
 define('SIU_CUSTOMER_DELETED', 'Customer %s deleted!');
 define('SURE_TO_DELETE', 'Are you sure you want to delete the user %s?');
?>