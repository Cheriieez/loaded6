<?php
/*
  $Id: affiliate_banners.php,v 2.00 2003/10/12

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Affiliate Program');
define('NAVBAR_TITLE_2', 'Newsletter Subscriptions');

define('HEADING_TITLE', 'Newsletter Subscriptions');

define('MY_NEWSLETTERS_TITLE', 'My Newsletter Subscriptions');
define('MY_NEWSLETTERS_AFFILIATE_NEWSLETTER', 'Affiliate Newsletter');
define('MY_NEWSLETTERS_AFFILIATE_NEWSLETTER_DESCRIPTION', 'Including affiliate news, new products, special offers, and other promotional announcements.');

define('SUCCESS_NEWSLETTER_UPDATED', 'Your newsletter subscriptions have been successfully updated.');
?>