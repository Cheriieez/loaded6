<?php
/*
  $Id: fdm_library_folders_edit.php,v 1.0.0.0 2006/10/09 23:39:49 datazen Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2006 CRE Loaded
  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Library Folder Edit');

define('TEXT_FOLDER_SORT_ORDER', 'Sort Order:');
define('TEXT_FOLDER_IMAGE', 'Folder Image:');
define('TEXT_FOLDER_PREV_IMAGE', 'Folder Previous Image:');
define('TEXT_FOLDER_NAME', 'Folder Name:');
define('TEXT_FOLDER_HEADING_TITLE', 'Heading Title:');
define('TEXT_FOLDER_DESCRIPTION', 'Description:');
define('TEXT_FOLDER_META_TITLE', 'Page META Title:');
define('TEXT_FOLDER_META_DESCRIPTION', 'Page META Description:');
define('TEXT_FOLDER_META_KEYWORDS', 'Page META Keywords:');
define('TEXT_FOLDER_DELETE_IMAGE', 'Delete');

?>