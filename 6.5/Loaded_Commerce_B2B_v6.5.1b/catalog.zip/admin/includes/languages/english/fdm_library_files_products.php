<?php
/*
  $Id: fdm_library_files_products.php,v 1.0.0.0 2006/10/12 13:41:11 datazen Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2006 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Products Attached to Library File');
define('TABLE_HEADING_SELECT', 'Select');
define('TABLE_LOGIN_REQUIRE', 'Login Require: ');
define('TABLE_PURCHASE_REQUIRE', 'ReqP: ');
define('TABLE_REQUIRE', 'Require<br>Purchase');
define('TEXT_IMAGE_NONEXISTENT', 'Image is not exist');
define('TABLE_HEADING_PRODUCTS', 'Products');

?>
