<?php
/*
  $Id: fdm_customer_top_downloads.php,v 1.0.0.0 2007/01/03 13:41:11 Eversun Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2006 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Customer Top Downloads');
define('TABLE_HEADING_CUSTOMER', 'Customer');
define('TABLE_HEADING_CUSTOMER_DOWNLOAD', 'Report');
define('TABLE_HEADING_FILES', 'Files');
define('TABLE_HEADING_FILES_DESC_NAME', 'Descriptive Name');
define('TABLE_HEADING_VIEWED', 'Downloads');
define('TEXT_DISPLAY_NUMBER_OF_FILES', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> downloads)');
define('TEXT_CUSTOMER_DOWNLOADS_REPORT', 'Report');
define('TEXT_ALL_FILES', 'All Files');
define('HEADING_TITLE_FILES', 'Files: ');
define('HEADING_TITLE_IP', 'Customer Top Downloads (IP List)');
define('TABLE_HEADING_DOWNLOAD_IP', 'Download IP');
define('TABLE_HEADING_DOWNLOAD_DATE', 'Download Date');
?>