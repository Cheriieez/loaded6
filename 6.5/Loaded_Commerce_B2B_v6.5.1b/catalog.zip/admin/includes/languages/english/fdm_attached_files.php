<?php
/*
  $Id: fdm_attached_files.php,v 1.0.0.0 2007/01/04 13:41:11 avicrw Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2006 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Files Attached to Products');
define('TABLE_HEADING_NUMBER', 'ID');
define('TABLE_HEADING_FILE_NAME', 'Filename');
define('TABLE_HEADING_PRODUCT_NAME', 'Product Name');
define('TABLE_HEADING_PRODUCT_ID', 'ID');
define('TABLE_HEADING_FILE_STATUS', 'File<br>Status');
define('TABLE_HEADING_PURCHASE_REQUIRED', 'Requires Purchase');
define('TABLE_HEADING_FILE_AVAILABILITY', 'File Availability');
define('TEXT_FILE_PURCHASE_TXT', 'Purchase');
define('TEXT_FILE_LOGIN', 'Login');
define('TEXT_FILE_FREE', 'Free');
define('TEXT_DISPLAY_NUMBER_OF_LINES', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> lines)');

?>