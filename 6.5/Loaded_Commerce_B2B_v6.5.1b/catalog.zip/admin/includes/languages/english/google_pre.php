<?php
/*

  Copyright (c) 2005 - 2007 Chainreactionworks.com
  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Google Base Data Feed');

define('TEXT_INFO_COMPLETED', 'Building feed files completed:');
define('TEXT_INFO_TIMER', 'Script timer:');
define('TEXT_INFO_SECOND', 'seconds.');

define('TEXT_INFO_DONE', 'Categores built return to data admin');

define('TEXT_OUTPUT_17', 'data feed: ');
define('TEXT_OUTPUT_18', 'File completed: ');
define('TEXT_OUTPUT_19', 'view output file');

define('TEXT_OUTPUT_20',' Run category build        run feed build    ');

?>