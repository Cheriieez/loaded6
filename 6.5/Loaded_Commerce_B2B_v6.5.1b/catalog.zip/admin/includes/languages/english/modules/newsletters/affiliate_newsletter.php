<?php
/*
  $Id: affiliate_newsletter.php,v 2.00 2003/10/12

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_COUNT_AFFILIATES', 'Affiliates receiving newsletter: %s');
define('TEXT_AFFILIATE_NEWSLETTER_NAME', 'Affiliate Newsletter');

?>