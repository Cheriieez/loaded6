<?php
/*
  $Id: download_newsletter.php,v 1.2 2004/03/05 00:36:42 Eversun Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_COUNT_CUSTOMERS', 'Customers receiving newsletter: %s');
define('TEXT_FILES', 'Files Downloaded');
define('TEXT_SELECTED_FILES', 'Selected Files');
define('JS_PLEASE_SELECT_FILES', 'Please select some files.');
define('BUTTON_GLOBAL', 'Global');
define('BUTTON_SELECT', '&gt;&gt;&gt;');
define('BUTTON_UNSELECT', '&lt;&lt;&lt;');
define('BUTTON_SUBMIT', 'Submit');
define('BUTTON_CANCEL', 'Cancel');
define('TEXT_FILE_NOTIFICATIONS_START_DATE', 'From:');
define('TEXT_FILE_NOTIFICATIONS_END_DATE', 'To:');
define('TEXT_FILE_EMAIL_VALIDATED', 'Send to only Validated Emails');
define('TEXT_FILE_RELEASED', 'Include Released Files that have not been downloaded');
define('TEXT_COUNTRIES', 'Countries');
define('TEXT_SELECTED_COUNTRIES', 'Selected Countries');
?>
