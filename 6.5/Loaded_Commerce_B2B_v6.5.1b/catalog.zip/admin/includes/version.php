<?php
/*
  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2008 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/
// define the project version
define('INSTALLED_VERSION_TYPE', 'proB2B');
define('INSTALLED_VERSION_MAJOR', '6');
define('INSTALLED_VERSION_MINOR', '5');
define('INSTALLED_PATCH', '1b');
define('INSTALLED_VERSION_REVISION', '446');
define('PROJECT_VERSION', 'Loaded Commerce B2B v'.INSTALLED_VERSION_MAJOR.'.'.INSTALLED_VERSION_MINOR.'.'.INSTALLED_PATCH);
?>
