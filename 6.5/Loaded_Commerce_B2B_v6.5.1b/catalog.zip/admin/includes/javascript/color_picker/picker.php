<?php


?>
<!--
Title: Tigra Color Picker
URL: http://www.softcomplex.com/products/tigra_color_picker/
Version: 1.1
Date: 06/26/2003 (mm/dd/yyyy)
Note: Permission given to use this script in ANY kind of applications if
   header lines are left unchanged.
Note: Script consists of two files: picker.js and picker.html
-->

<html>
<head>
    <title>Color Picker</title>
    <style>
        .bd { border : 1px inset InactiveBorder; }
        .s  { width:181 }
    </style>
</head>
<body leftmargin="5" topmargin="5" marginheight="5" marginwidth="5" onload="P.C(P.initPalette)">
<table cellpadding=0 cellspacing=2 border=0 width=250>
<form>
<tr><td align="center">
<select name="type" onchange="P.C(this.selectedIndex)" class="s">
    <option>Web Safe Palette</option>
    <option>Windows System Palette</option>
    <option>Grey Scale Palette</option>
    <option>Mac OS Palette</option>
</select>
</td></tr>
<tr><td align="center">
<script language="JavaScript">
    var P = opener.TCP;
    onload = "P.show(P.initPalette)";
    document.forms[0].elements[0].selectedIndex = P.initPalette;
    P.draw(window, document);
</script>
</td></tr>
</form>
</table>
</body>
</html>
