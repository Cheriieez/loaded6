<?php
/*
  $Id: editor.php,v 1.0.0.0 2008/05/28 13:41:11 wa4u Exp $

  CRE Loaded, Open Source E-Commerce Solutions
  http://www.creloaded.com

  Copyright (c) 2008 CRE Loaded
  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License

*/
/************
Left this file to suppress errors in old applications, modules and addons.
***********/
?>