
<img src="http://tiger.census.gov/cgi-bin/mapgen?lon=<?php echo $_GET['ip_longitude'];?>&lat=<?php echo $_GET['ip_latitude']; ?>&wid=.45&ht=.3&iht=300&iwd=450&mark=<?php echo $_GET['ip_longitude'];?>,<?php echo $_GET['ip_latitude'];?>,redball"> 
<!-- <p>Courtesy of the U.S. Census Bureau's TIGER Mapping Service --><?php echo MAP_MSG;?>
