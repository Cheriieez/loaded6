<?php
/*
  $Id: quick_updates_filenames.php, 2008/02/20 maestro

  ContributionCentral, Custom CRE Loaded & osCommerce Programming
  http://www.contributioncentral.com
  Copyright (c) 2008 ContributionCentral

  Released under the GNU General Public License
*/

// Quick Updates Filenames
  define('FILENAME_QUICK_UPDATES', 'quick_updates.php');

?>
