<?php
$colors = array(
                "lightgreen" => array(0, 255, 0),
                "darkgreen" => array(0, 80, 0),

                "lightorange" => array(255, 102, 0),
                "darkorange" => array(160, 65, 10),

                "lightblue" => array(0, 0, 255),
                "darkblue" => array(0, 0, 80),
        
        "lightgray" => array(192, 192, 192),
                "darkgray" => array(144, 144, 144),

                "lightyellow" => array(255, 255, 0),
                "darkyellow" => array(200, 200, 50),

                "lightcyan" => array(0, 255, 255),
                "darkcyan" => array(0, 90, 90),

                "lightbrown" => array(166, 124, 81),
                "darkbrown" => array(117, 76, 35),

                "lightmagenta" => array(240, 110, 170),
                "darkmagenta" => array(158, 0, 93),

                "lightviolet" => array(96, 92, 168),
                "darkviolet" => array(26, 19, 100),

                "lightred" => array(255, 0, 0),
                "darkred" => array(128, 0, 0),

                "lightygreen" => array(124, 197, 118),
                "darkygreen" => array(23, 123, 47),

                "lightgcyan" => array(27, 187, 180),
                "darkgcyan" => array(0, 115, 106)
               );
?>