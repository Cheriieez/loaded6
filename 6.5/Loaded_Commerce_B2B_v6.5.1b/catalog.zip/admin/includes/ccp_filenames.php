<?php
/*
  $Id: ccp_filenames.php, v1.0.0.0 2008/02/20 maestro

  ContributionCentral, Custom CRE Loaded & osCommerce Programming
  http://www.contributioncentral.com
  Copyright (c) 2008 ContributionCentral

  Released under the GNU General Public License
*/

  //Change Password
  define('FILENAME_CHANGE_PASSWORD', 'change_password.php');

?>
